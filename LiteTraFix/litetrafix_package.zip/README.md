# LiteTraFix
## Headless Network Traffic Simulator — Sandboxed Cybersecurity Training

Simulates realistic HTTP traffic to the top 20 US domains across your lab
network. No GUI, no extra dependencies — pure Python 3 stdlib. Drop the
scripts, chmod, run.

---

## Files

| File | Where it goes | Purpose |
|---|---|---|
| `mock_server.py` | DMZ host | Listens on port 80, responds 200 to all domains |
| `litetrafix.py` | Internal host(s) | Writes dnsmasq config, generates HTTP traffic |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  INTERNAL NETWORK                                        │
│                                                          │
│  [Internal Box]                                          │
│   ./litetrafix.py  ──DNS query (port 53)──►  [ROUTER]   │
│                    ◄──DNS reply ───────────             │
│                    ──HTTP GET  (port 80)──►             │
│                    ◄──HTTP 200 ─────────────            │
│                                           │             │
└───────────────────────────────────────────┼─────────────┘
                                            │
                              Router sees ALL traffic here
                              ← best Wireshark placement
                                            │
┌───────────────────────────────────────────┼─────────────┐
│  DMZ                                      │             │
│                                           ▼             │
│  [DMZ Host]                                             │
│   dnsmasq     (port 53) — redirects all domains → self  │
│   mock_server.py (port 80) — responds 200 to everything │
└─────────────────────────────────────────────────────────┘
```

**Wireshark placement:** Monitor the router interface facing the internal
network. Every DNS query and HTTP GET from litetrafix.py crosses it twice.

---

## Prerequisites

### DMZ host
```bash
sudo apt update && sudo apt install dnsmasq -y
sudo systemctl enable dnsmasq
```

### Internal host(s)
Nothing — litetrafix.py uses only Python 3 stdlib.

### Both scripts
```bash
chmod +x mock_server.py litetrafix.py
```

---

## Setup

### 1. Point internal hosts at the DMZ server (once per host)

**Temporary (lost on reboot):**
```bash
echo "nameserver <DMZ_HOST_IP>" | sudo tee /etc/resolv.conf
```

**Permanent:**
```bash
sudo systemctl disable --now systemd-resolved
sudo rm -f /etc/resolv.conf
echo "nameserver <DMZ_HOST_IP>" | sudo tee /etc/resolv.conf
sudo chattr +i /etc/resolv.conf   # optional: make immutable
```

### 2. Start the mock server (DMZ host)
```bash
sudo ./mock_server.py
```

### 3. Apply DNS + generate traffic (internal host)
```bash
sudo ./litetrafix.py --server-ip <DMZ_HOST_IP> --apply-dns --cycles 3
```

---

## Usage

### mock_server.py (DMZ host)

```
sudo ./mock_server.py [OPTIONS]

Options:
  --host ADDR    Bind address (default: 0.0.0.0)
  --port PORT    Listen port  (default: 80, requires sudo)
  -q             Quiet — errors only
```

### litetrafix.py (internal host)

```
sudo ./litetrafix.py [OPTIONS]

DNS options:
  --server-ip IP      DMZ host IP (required with --apply-dns)
  --apply-dns         Write dnsmasq config and restart dnsmasq
  --clear-dns         Remove dnsmasq config and restart dnsmasq
  --domains D [D...]  Subset of domains (default: all 21)
  --show-dns          Print current dnsmasq config and exit

Traffic options:
  --cycles N     Number of full domain sweeps (default: 1)
  --delay SEC    Seconds between requests    (default: 2.0)
  --threads N    Concurrent requests         (default: 4)

Misc:
  -q / --quiet   Errors only
  -h / --help    Full help
```

### Common commands

```bash
# Apply DNS + run 3 cycles
sudo ./litetrafix.py --server-ip 192.168.1.254 --apply-dns --cycles 3

# Traffic only (DNS already set)
sudo ./litetrafix.py --cycles 5 --delay 1 --threads 8

# Custom domain subset
sudo ./litetrafix.py --server-ip 192.168.1.254 --apply-dns \
    --domains google.com youtube.com reddit.com cnn.com

# Check what's deployed to dnsmasq
sudo ./litetrafix.py --show-dns

# Clean up DNS when done
sudo ./litetrafix.py --clear-dns
```

---

## Domains Simulated (default)

google.com · youtube.com · facebook.com · amazon.com · wikipedia.org ·
twitter.com · x.com · reddit.com · instagram.com · linkedin.com ·
netflix.com · bing.com · microsoft.com · apple.com · espn.com ·
cnn.com · nytimes.com · twitch.tv · ebay.com · yahoo.com · zoom.us

---

## Wireshark Filter

```
ip.addr == <DMZ_HOST_IP> && (dns || http)
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Permission denied` writing dnsmasq config | Run litetrafix.py with sudo |
| dnsmasq won't start | `sudo journalctl -u dnsmasq -n 30` |
| Internal host not resolving | Check `/etc/resolv.conf` has DMZ host IP |
| `systemd-resolved` overwriting resolv.conf | `sudo systemctl disable --now systemd-resolved` |
| mock_server port 80 denied | Run with sudo or use `--port 8080` |
| HTTP 0 in litetrafix output | Confirm mock_server.py is running on DMZ host |
| dnsmasq port 53 conflict | `sudo systemctl disable --now systemd-resolved` first |
