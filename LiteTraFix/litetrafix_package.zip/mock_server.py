#!/usr/bin/env python3
"""
mock_server.py — LiteTraFix Mock HTTP Server
=============================================
Runs on the DMZ host. Accepts HTTP requests for any of the simulated
domains and returns a realistic-looking 200 response. Logs every
request with timestamp, source IP, Host header, and path.

Setup (once):
  chmod +x mock_server.py

Usage:
  sudo ./mock_server.py [--host 0.0.0.0] [--port 80] [-q]

Examples:
  sudo ./mock_server.py
  sudo ./mock_server.py --port 8080        # unprivileged port (no sudo)
  sudo ./mock_server.py -q                 # errors only
"""

import argparse
import sys
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

QUIET = False

def ts():
    return datetime.now().strftime("%H:%M:%S")

def log(msg, level="INFO"):
    if QUIET and level == "INFO":
        return
    tag = {"INFO": "\033[36mINFO\033[0m", "OK":   "\033[32m OK \033[0m",
           "WARN": "\033[33mWARN\033[0m", "ERR":  "\033[31m ERR\033[0m"}.get(level, level)
    print(f"[{ts()}] [{tag}] {msg}", flush=True)

# ---------------------------------------------------------------------------
# Request handler
# ---------------------------------------------------------------------------

# Minimal but believable HTML body for each response
HTML_TEMPLATE = """\
<!DOCTYPE html>
<html>
<head><title>{host}</title></head>
<body>
<h1>Welcome to {host}</h1>
<p>This page is simulated by LiteTraFix mock_server.</p>
</body>
</html>
"""

class MockHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        host = self.headers.get("Host", "unknown").split(":")[0]
        client_ip = self.client_address[0]
        log(f"{client_ip} → GET {host}{self.path}", "OK")

        body = HTML_TEMPLATE.format(host=host).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Server", "nginx/1.24.0")   # realistic server header
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def do_HEAD(self):
        host = self.headers.get("Host", "unknown").split(":")[0]
        client_ip = self.client_address[0]
        log(f"{client_ip} → HEAD {host}{self.path}", "OK")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Server", "nginx/1.24.0")
        self.send_header("Connection", "close")
        self.end_headers()

    # Suppress default BaseHTTPRequestHandler access log (we do our own)
    def log_message(self, fmt, *args):
        pass

    def log_error(self, fmt, *args):
        log(fmt % args, "ERR")

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------

BANNER = r"""
  _     _ _       _____          _____ _
 | |   (_) |     |_   _|        |  ___(_)
 | |    _| |_ ___ | |_ __ __ _  | |_   ___  __
 | |   | | __/ _ \| | '__/ _` | |  _| | \ \/ /
 | |___| | ||  __/| | | | (_| | | |   | |>  <
 |_____|_|\__\___\___/_|  \__,_| \_|   |_/_/\_\

 LiteTraFix — Mock HTTP Server
"""

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="LiteTraFix mock HTTP server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    p.add_argument("--port", type=int, default=80, help="Listen port (default: 80)")
    p.add_argument("-q", "--quiet", action="store_true",
                   help="Suppress INFO messages (only OK/WARN/ERR)")
    return p.parse_args()

def main():
    global QUIET
    args = parse_args()
    QUIET = args.quiet

    if not QUIET:
        print(BANNER)

    try:
        server = HTTPServer((args.host, args.port), MockHandler)
    except PermissionError:
        log(f"Cannot bind to port {args.port} — run with sudo, or use --port 8080", "ERR")
        sys.exit(1)
    except OSError as e:
        log(f"Cannot start server: {e}", "ERR")
        sys.exit(1)

    log(f"Listening on {args.host}:{args.port} — Ctrl+C to stop")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("Shutting down.", "WARN")
        server.shutdown()

if __name__ == "__main__":
    main()
